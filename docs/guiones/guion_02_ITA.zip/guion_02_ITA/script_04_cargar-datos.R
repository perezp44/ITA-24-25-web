#- script para seguir las slides_04_cargar-datos 

#- pp. 4 -----------------------------------------------------------------------
#- Tarea: descargar un fichero de datos con R

#- Solution

my_url <- "https://raw.githubusercontent.com/perezp44/archivos_download/refs/heads/master/plazas_turisticas.csv"

fs::dir_create("pruebas")

download.file(my_url, "./pruebas/plazas_turisticas.csv")

download.file(url = my_url,
              destfile = "./pruebas/plazas_turisticas.csv")

#- Extended solution

my_url <- "https://raw.githubusercontent.com/perezp44/archivos_download/refs/heads/master/plazas_turisticas.csv"  

my_ruta <- "./pruebas/plazas_turisticas.csv"

curl::curl_download(url = my_url,
                    destfile = my_ruta)   

#- pp. 6 -----------------------------------------------------------------------
#- intenta entender el siguiente chunk de código

#- cuando iniciamos R se cargan automáticamente un grupo de paquetes (R-base)
print(.packages()) #- [🌶]imprimimos los nombres de los "currently attached packages"

#- en uno de esos paquetes hay un conjunto de datos llamado "iris"
iris          #- llamamos a "iris"
find("iris")  #- [🌶] ¿donde está iris?
str(iris)     #- qué es iris?


my_iris <- iris  #- "hacemos una copia" de iris en el Global
find("my_iris")  #- ¿donde está my_iris?

iris <- c(2, 4)    #- creamos un vector llamado iris
find("iris")       #- ¿donde está ahora iris?


rm(list = ls())
#- pp. 7 -----------------------------------------------------------------------
#- Tarea: usar unos datos de un paquete

#- Solution
library(palmerpenguins)

mys_pinguinos <- penguins

#- Extended solution
mys_pinguinos <- palmerpenguins::penguins


rm(list = ls())
#- pp. 12 ----------------------------------------------------------------------
#- Tarea: importar a R datos que tenemos guardados en nuestro ordenador

#- Solution
my_ruta <- "./pruebas/plazas_turisticas.csv"

df <- rio::import(my_ruta)


#- Extended solution
my_ruta <- "./pruebas/plazas_turisticas.csv"   

df <- rio::import(file = my_ruta)


rm(list = ls())
#- pp. 16 ----------------------------------------------------------------------
#- Tarea: exportar unos datos de R a un fichero


#- Solution
df <- iris

rio::export(df, "./pruebas/iris.csv")


#- Extended solution
df <- iris  

rio::export(x = df,
            file = "./pruebas/iris.csv")


#- pp. 18 ----------------------------------------------------------------------
#- Práctica: importar/exportar datos

fs::dir_delete("pruebas")    
fs::dir_create("pruebas")    


#- Solution (está vez has de hacerlo tú)



#- pp. 19 ----------------------------------------------------------------------
#- Eurostat: 

# install.packages("eurostat")
library(eurostat)

#- importamos los datos de la tabla "cult_emp_sex": "Cultural employment by sex"
df <- eurostat::get_eurostat("cult_emp_sex")   



#- pp. 20 ----------------------------------------------------------------------
#- Eurostat: importando datos en R

library(eurostat)

#- podemos buscar un  "tema" con la f. search_eurostat()
aa <- search_eurostat("employment", type = "all") 

#- elegimos una tabla de Eurostat
#- "hlth_silc_17": "Healthy life expectancy based on self-perceived health"
my_table <- "hlth_silc_17"  

#- da información sobre la Base de datos q hemos elegido
label_eurostat_tables(my_table) 

#-  descargamos los datos con get_eurostat()
df <- get_eurostat(my_table, time_format = "raw", keepFlags = TRUE )   

#- pone labels/etiquetas: mas legible, menos fácil de programar
df_l <- label_eurostat(df)       


#- pp. 21 ----------------------------------------------------------------------
#- Practica: importar datos de Eurostat

library(eurostat)

#- podemos buscar un  "tema" con la f. search_eurostat()
my_tema <- "employment"

aa <- eurostat::search_eurostat(pattern = my_tema, type = "all") 

#- elegimos una tabla; por ejemplo "hlth_silc_17"
my_table <- "hlth_silc_17" 

#- da información sobre la Base de datos que estas buscando
eurostat::label_eurostat_tables(my_table) 

#-  importamos los datos de "my_table" con get_eurostat()
df <- eurostat::get_eurostat(my_table, time_format = "raw", keepFlags = TRUE )   

#- pedimos los descriptores/labels de las series
df_l <- eurostat::label_eurostat(df) 


#- pp. 22 ----------------------------------------------------------------------
#- El paquete quantmod

library(quantmod)  #- install.packages("quantmod")

#- For stocks and shares, the yahoo source is used. 
facebook  <- getSymbols(Symbols = 'F', src = 'yahoo', auto.assign = FALSE)  
barChart(facebook) 

#- For currencies and metals, the oanda source is used.
tc_euro_dolar <- getSymbols(Symbols = 'EUR/USD', src = 'oanda', auto.assign = FALSE)

#- For economics series, the FRED source is used. 
Japan_GDP <- getSymbols(Symbols = 'JPNNGDP', src = 'FRED', auto.assign = FALSE)



#- EXTENSIONES -----------------------------------------------------------------


rm(list = ls())
#- pp. 25 ----------------------------------------------------------------------
#- Formato .rds

#- exportar a .rds
rio::export(x = iris, file = "./pruebas/iris.rds")   

#- importar de .rds
df <- rio::import(file = "./pruebas/iris.rds")


#- pp. 26 ----------------------------------------------------------------------
#- Formato .RData (o .rda)

#- exportar a .rda (o .RData)
#- guardamos los objetos mtcars e iris en un fichero llamado "mtcars_and_iris.RData"
save(mtcars, iris,  file = "./pruebas/mtcars_and_iris.RData")


#- importar de .rda (o .RData)
load(file = "./pruebas/mtcars_and_iris.RData")



#- pp. 27 ----------------------------------------------------------------------
#- Bonus 1 (🌶🌶): exportar los datos de un df en un archivo .xlsx ya existente


#- bonus: le añadimos un libro mas al archivo "./pruebas/iris.xlsx"

rio::export(iris, "./pruebas/iris.xlsx")  #- por si acaso lo hubiésemos borrado


rio::export(iris, "./pruebas/iris.xlsx", which = "iris_2")

#- lo mismo pero poniendo los nombres de los argumentos
rio::export(x = iris, 
            file ="./pruebas/iris.xlsx", 
            which = "iris_3")



#- pp. 28 ----------------------------------------------------------------------
#- Bonus 2 (🌶🌶🌶🌶): exportar 2 df’s en un único archivo .xlsx

rio::export(x = list(iris = iris, 
                     pinguinos = palmerpenguins::penguins), 
            file = "./pruebas/my_iris_pinguinos.xlsx")


#- pp. 29 ----------------------------------------------------------------------
#- Bonus 3 (🌶🌶): importar una hoja/libro especifica de un archivo .xlsx

iris_1 <- rio::import("./pruebas/my_iris_pinguinos.xlsx")  #- solo importa el primer libro


pinguinos_1 <- rio::import("./pruebas/my_iris_pinguinos.xlsx", sheet = 2)


pinguinos_2 <- rio::import(file = "./pruebas/my_iris_pinguinos.xlsx", 
                           sheet = "pinguinos")



#- pp. 30 ----------------------------------------------------------------------
#- Webscrapping [🌶🌶🌶 🌶🌶]


library(rvest)
library(tidyverse)
my_url <- "https://es.wikipedia.org/wiki/Anexo:Municipios_de_la_provincia_de_Teruel"
content <- read_html(my_url)

body_table <- content %>%
  html_nodes('body')  %>%
  html_nodes('table') %>%
  html_table(dec = ",")

#- solo hay una tabla
Teruel <- body_table[[1]]  #- estoy haciendo subsetting de una lista



#- pp. 32 ----------------------------------------------------------------------
#- seleccionando “manualmente” un archivo de datos
my_data <- rio::import(file.choose())
