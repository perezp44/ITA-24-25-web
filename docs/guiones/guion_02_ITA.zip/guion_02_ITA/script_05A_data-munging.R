#- script para seguir las slides_05A_data-munging 

#- The pipe
#- pp. 7 -----------------------------------------------------------------------

head(iris, n = 4)         #- forma habitual de llamar/usar la función head()

iris %>% head(. , n = 4)  #- usando el operador pipe


#- pp. 8 -----------------------------------------------------------------------

head(iris, n = 4)         #- forma habitual de llamar/usar la función head()

iris %>% head(. , n = 4)  #- usando el operador pipe (con el punto actuando como placeholder)

iris %>% head(n = 4)      #- usando el operador pipe (SIN el punto)


4 %>% head(iris, .)

4 %>% head(iris)


letters %>% paste0( "-----" ,  .  ,  "!!!" ) %>% toupper




#- Tarea: convierte “df_wide” a formato LARGO
#- pp. 16 ----------------------------------------------------------------------

df_wide <- data.frame(students = c("Pedro", "Carla", "María"), 
                      w_2014 = c(100, 400, 200), 
                      w_2015 = c(500, 600, 700),
                      w_2016 = c(200, 250, 900) )


#- Solution
#- la función pivot_longer() transforma los datos de formato ancho(wide) a formato largo(long)
library(tidyverse)

df_long <- df_wide %>% 
  tidyr::pivot_longer(cols = 2:4)

knitr::kable(df_long)




#- Extended solution
#- la función pivot_longer() transforma los datos de formato ancho(wide) a formato largo(long)
df_long <- df_wide %>% 
  tidyr::pivot_longer(cols = 2:4, 
                      names_to = "periodo", 
                      values_to = "salario")
knitr::kable(df_long)


#- Tarea: convierte “df_long” a formato ANCHO
#- una columna para cada año
#- pp 18 -----------------------------------------------------------------------


#- Solution

df_wide2 <- df_long %>% 
  tidyr::pivot_wider(values_from = salario,  
                     names_from = periodo)



#- Tarea: convierte OTRA VEZ “df_long” a formato ANCHO
#- ahora una columna para cada persona
#- pp 20 -----------------------------------------------------------------------

df_wide2 <- df_long %>% 
  tidyr::pivot_wider(values_from = salario, 
                     names_from = students)
knitr::kable(df_wide2)

