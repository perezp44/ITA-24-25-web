#- https://martinctc.github.io/blog/Copy-and-paste_wordclouds_in_R/   (word cloud desde el portapapeles)

#install.packages("wordcloud2")
library(wordcloud2)

# have a look to the example dataset
aa <- demoFreq
wordcloud2(demoFreq, size = 1.6)

# Gives a proposed palette
wordcloud2(demoFreq, size = 1.6, color = 'random-dark')

# or a vector of colors. vector must be same length than input data
wordcloud2(demoFreq, size = 1.6, color = rep_len( c("green","blue"), nrow(demoFreq) ) )

# Change the background color
wordcloud2(demoFreq, size = 1.6, color= 'random-light', backgroundColor = "black")


# Change the shape:
wordcloud2(demoFreq, size = 0.7, shape = 'star')

wordcloud2(demoFreq, size = 0.7, shape = 'pentagon', color = "skyblue", backgroundColor="black")


# Change the shape using your image (no me funciona!!)
#wordcloud2(demoFreq, figPath = "./imagenes/peace.png", size = 1.5, color = "skyblue", backgroundColor="black")

#- mas ejemplos
ww <- wordcloud2(demoFreq, size = 2.3, minRotation = -pi/6, maxRotation = -pi/6, rotateRatio = 1)
ww
wordcloud2(demoFreq, size = 2, fontFamily = "微软雅黑", color = "random-light", backgroundColor = "grey")


#- no acaban de funcionar las letras (!! x pb de size)
letterCloud(demoFreq, word = "R", color='random-light' , backgroundColor="black")
letterCloud(demoFreq, word = "P", color="white", backgroundColor="pink", wordSize = 3)

