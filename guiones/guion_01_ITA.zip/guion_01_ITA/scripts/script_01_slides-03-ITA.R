#- script to follow slides_03_R-base-01_val.R

#- pp 5 ------------------------------------------------------------------------
#- Creació d'objectes i assignació (<-)

#- Quines diferències hi ha entre les següents 2 expressions?
2 + 2
aa <- 2 + 2

#- una vegada hem creat una variable, podem fer-la servir per efectuar nous càlculs
aa + 1

#- podem canviar el valor d'una variable
aa
aa <- 10
aa

#- Què fan les següents línies de codi?
aa <- 2 + 2
bb <- 5 + aa
cc <- 1 + aa * 2
dd <- bb


#- pp 6 ------------------------------------------------------------------------
#- Global environment (primera referència al)

aa <- 2 + 2
bb <- 5 + aa
cc <- 1 + aa * 2
dd <- bb

ls()                #- mostra els objectes q hi ha al Global env.
rm(cc)              #- esborra/elimina l'objecte cc del Global env.
rm(list = ls())     #- esborra tots els objectes del Global env.


#- pp 8 ------------------------------------------------------------------------
#- Tipus de dades

aa <- "La calle en la que vivo es"    #- text (character)
bb <- 4L                              #- nombre sencer
cc <- 4.3                             #- nombre decimal
dd <- TRUE                            #- logical

typeof(aa)
typeof(dd)



#- pp 9 ------------------------------------------------------------------------
#- Operacions amb variables numèriques

#- operacions aritmètiques
2 + 2
5 * 6

#- Operacions de comparació

2 < 4    # MENOR que: aquesta expressió revisa si 2 és MENOR que quatre. Com és cert, torna TRUE
2 > 4    # MAJOR que: aquesta expressió revisa si 2 és MAJOR que quatre. Com és cert, torna TRUE
5 >= 7   # MAJOR o IGUAL que.
8 <= 8   # MENOR o IGUAL que.
5 == 4   # == IGUAL: == revisa si dos valors són iguals, com no són iguals tornarà FALSE
2 != 4   # NO IGUAL: com que 2 no és igual a 4 ens torna TRUE
5 != 5   # NO IGUAL: com que 5 és igual a 5, ens torna FALSE


2 = 2    #- què passa? per què es queixa R?


#- pp 10 -----------------------------------------------------------------------
#- Operacions amb text

aa <- "mi nombre es"
bb <- "pedro"
paste(aa, bb)
paste(aa, bb, sep = " ... ")
# Prova tu mateix que fa la funció paste0()



toupper(aa)
tolower(aa)
nchar(bb)                      #- nchar() ens torna el nombre de caràcters d'un string
substring(bb, 2, nchar(bb))    #- substring() extreu caràcters d'un string  [🌶🌶]


#- pp 11 -----------------------------------------------------------------------
#- Operacions lògiques

TRUE & TRUE     #- AND: perquè torne TRUE cal que TOTES les condicions siguen certes
TRUE & FALSE
FALSE & FALSE

TRUE | TRUE     #- OR: torna TRUE si ALGUNA de les condicions és certa
TRUE | FALSE
FALSE | FALSE

!TRUE           #- NOT: torna el valor contrari
!FALSE



(4 > 3) & (3 < 2)  #- AND: com que només es compleix la primera condició, ens torna FALSE

(1==2) | (2 >3)    #- OR: Com que no es compleix cap de les 2 condicions ens torna FALSE

!(4 > 3)           #- NOT: 4 més gran que 3 és TRUE, però el ! davant d'aquesta condició la nega i passa a FALSE
!!(4 > 3)          #- si negues dues vegades, tornes al principi: TRUE


#- pp 16 -----------------------------------------------------------------------
#- Com crear un vector?

aa <- c(3, 22, 6)

aa
is.vector(aa)
typeof(aa)

#- TASCA -----
#- Tasca: crea un vector de tipus character amb 3 elements



#- pp 17 -----------------------------------------------------------------------
#- Coerció (implicita)
aa <- c(4, 6,  "Hola")  #- intentem posar aa elements numèrics i character (?)

is.vector(aa)
typeof(aa)       #- què ha passat?
aa               #- què ha passat?


#- Coerció (explicita)
aa <- c(1:4)
aa
aa <- as.character(aa)
aa


#- pp 19 -----------------------------------------------------------------------
#- 3 tipus de subsetting

#- 1. Seleccionar per posició

aa <- c(10:1)
aa[c(1:2)]           #- primer i segon element del vector
aa[c(1, 2, 9, 10)]   #- dos primers i 2 darrers elements

#- 2. Eliminar per posició

aa <- c(10:1)
aa[-2]
aa[- c(1, 2, 9:10)]

#- 3. Subsetting lògic

aa <- 1:10
aa[aa >= 7]
aa[aa < 4]
aa[(aa >= 9) | (aa < 2)]
aa[(aa >= 9) & (aa < 2)]

#- pp 20 -----------------------------------------------------------------------
#- Intenta entendre bé el següent chunk. És important!!

aa <- 1:10

aa <= 4

aa[aa <= 4]

aa <- aa[aa <= 4]

aa

#- Modificar elements d'un vector

aa <- c(1:10)
aa[4] <- 88             #- el quart element de aa prendrà el valor 88
aa <- c(aa, 111, 112)   #- afegim 2 elements al vector aa



#- Els vectors es poden concatenar

aa <- c(1:5)
bb <- c(100:105)
cc <- c(aa, bb)


#- pp 21 -----------------------------------------------------------------------
#- Operacions amb vectors
#- Generalment són operacions element a element


aa <- 1:10
bb <- 1:10
aa + bb
aa * bb


#- Recycling

aa <- 1:10
aa + 1


#- pp 22 -----------------------------------------------------------------------
#- Funcions vectoritzades

aa <- c(4, 9, 25)

sqrt(aa)


#- Operacions de comparació

aa <- 1:3
bb <- 3:1

aa == bb
aa >= bb
aa != bb



#- pp 26 -----------------------------------------------------------------------
#- Creació de data frame's

#- creem 3 vectors de la mateixa longitud
aa <- c(4, 8, 6, 3)
bb <- c("Juan", "Paz", "Adrian", "Marquitos")
cc <- c(FALSE, TRUE, TRUE, FALSE)
#- agrupem els 3 vectors en un data.frame
df <- data.frame(aa, bb, cc)
#- vegem el data.frame. Veurem que les columnes tenen nom
df

#- posem noms als vector/columnes
df <- data.frame(Nota = aa, Nombre = bb, Aprobado = cc)


#- pp 27 -----------------------------------------------------------------------
#- subsetting amb data frames

#- subsetting com si fos una matriu: amb [ ]

df_s <- df[,1]        #- seleccionem la primera columna
df_s <- df[,c(2,3)]   #- seleccionem la segona i tercera columna
df_s <- df[1, ]       #- seleccionem primera fila de totes les variables.
df_s <- df[c(1,4), ]  #- seleccionem primera i quarta fila
df_s <- df[2, 3]      #- ¿?


#- subsetting como si fuera una lista: amb [, [[ i $

#- Com llista amb [
df_s <- df[3]       
df_s <- df[c(1,2)]
#- també es pot fer per nom
df_s <- df["Name"]              
df_s <- df[c("Name", "Grade")]

#- Com llista amb [[
df_s <- df[[2]]   #-  Extraiem la segona columna


#- Com llista amb $
df_s <- df$Name    #- Extraiem la columna amb nom "Name".
df_s <- df$Grade   #-  Extraiem la columna amb nom "Grade".



#- pp 31 -----------------------------------------------------------------------

#- TASCA----
#- Tasca: crea una funció que permeta sumar 2 números


#- pp 32 -----------------------------------------------------------------------
#- saber consultar l'ajuda d'una funció is VERY important [ 🌟 ]
help(sqrt)


#- pp 33 -----------------------------------------------------------------------
#- seguim amb les funcions

sqrt(9)
sqrt(9, 4)   #- no funciona, per què? quants arguments té la f. sqrt()?
sqrt("9")    #- no funciona, per què? de quin tipus ha de ser l'argument?


#- pp 34 -----------------------------------------------------------------------
#- seguim amb les funcions (més detalls) [🌶🌶🌶]


sqrt(9)       #- en realitat "no cal" posar el nom de l'argument
sqrt(x = 9)   #- 
sqrt(x = 4)


#- Aprendrem a diferenciar el nom i el valor de l'argument d'una funció:
sqrt(9)
sqrt(x = 9)

x <- 25
sqrt(x)
sqrt(x = x)          #- !!! quin és el nom i el valor de l'argument?
sqrt(x = un_valor)   #- !!! què passa?
sqrt(nn = 9)         #- !!! què passa?



#- pp 35 -----------------------------------------------------------------------
#- TASCA----
#- Tasca: calcular amb R el logaritme de 1000 a la base 10






#- pp 37 -----------------------------------------------------------------------
#- Com m'instal·lo un paquet? (Forma habitual)

# install.packages("dplyr")    #- instal·lem el pkg dplyr al nostre ordinador
library(dplyr)               #- carreguem dplyr en memòria de R per així poder utilitzar-lo


# install.packages("remotes")    #- #- prèviament cal instal·lar el pkg remotes
remotes::install_github("tidyverse/dplyr")   #- instal·lem la versió de github del pkg dplyr